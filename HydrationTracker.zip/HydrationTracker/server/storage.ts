// Memory storage implementation for development
import { IUser } from './models/User';
import { ISurvey } from './models/Survey';
import { IQuestion } from './models/Question';
import { ISurveyAssignment } from './models/SurveyAssignment';

export class MemoryStorage {
  private users: Map<string, any> = new Map();
  private surveys: Map<string, any> = new Map();
  private questions: Map<string, any> = new Map();
  private assignments: Map<string, any> = new Map();

  constructor() {
    // Create default admin user
    this.users.set('admin', {
      _id: 'admin-id',
      identifier: 'admin',
      type: 'name',
      role: 'admin',
      name: 'مدير النظام',
      isActive: true,
      createdBy: 'system',
      createdAt: new Date(),
      updatedAt: new Date()
    });

    // Create test user
    this.users.set('user1', {
      _id: 'user1-id',
      identifier: 'user1',
      type: 'name',
      role: 'user',
      name: 'مستخدم تجريبي',
      isActive: true,
      createdBy: 'admin',
      createdAt: new Date(),
      updatedAt: new Date()
    });
  }

  // User methods
  async findUserByIdentifier(identifier: string) {
    return this.users.get(identifier) || null;
  }

  async createUser(userData: any) {
    const id = Date.now().toString();
    const user = {
      _id: id,
      ...userData,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.users.set(userData.identifier, user);
    return user;
  }

  async getAllUsers(filter: any = {}) {
    const users = Array.from(this.users.values());
    return users.filter(user => {
      if (filter.role && user.role !== filter.role) return false;
      if (filter.isActive !== undefined && user.isActive !== filter.isActive) return false;
      return true;
    });
  }

  async findUserById(id: string) {
    for (const user of this.users.values()) {
      if (user._id === id) return user;
    }
    return null;
  }

  async updateUser(id: string, updateData: any) {
    const user = await this.findUserById(id);
    if (user) {
      Object.assign(user, updateData, { updatedAt: new Date() });
      return user;
    }
    return null;
  }

  async deleteUser(id: string) {
    for (const [key, user] of this.users.entries()) {
      if (user._id === id) {
        this.users.delete(key);
        return true;
      }
    }
    return false;
  }

  // Survey methods
  async createSurvey(surveyData: any) {
    const id = Date.now().toString();
    const survey = {
      _id: id,
      ...surveyData,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.surveys.set(id, survey);
    return survey;
  }

  async getSurveysByCreator(createdBy: string) {
    return Array.from(this.surveys.values()).filter(survey => survey.createdBy === createdBy);
  }

  async findSurveyByUniqueNumber(uniqueNumber: string) {
    for (const survey of this.surveys.values()) {
      if (survey.uniqueNumber === uniqueNumber) return survey;
    }
    return null;
  }

  // Question methods
  async createQuestion(questionData: any) {
    const id = Date.now().toString();
    const question = {
      _id: id,
      ...questionData,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.questions.set(id, question);
    return question;
  }

  async getQuestionsBySurveyId(surveyId: string) {
    return Array.from(this.questions.values())
      .filter(question => question.surveyId === surveyId)
      .sort((a, b) => a.order - b.order);
  }

  async deleteQuestion(id: string) {
    return this.questions.delete(id);
  }

  async updateQuestion(id: string, updateData: any) {
    const question = this.questions.get(id);
    if (question) {
      Object.assign(question, updateData, { updatedAt: new Date() });
      return question;
    }
    return null;
  }

  // Assignment methods
  async createAssignment(assignmentData: any) {
    const id = Date.now().toString();
    const assignment = {
      _id: id,
      ...assignmentData,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.assignments.set(id, assignment);
    return assignment;
  }

  async getAssignmentsByUserId(userId: string) {
    return Array.from(this.assignments.values()).filter(assignment => assignment.userId === userId);
  }

  async findAssignment(surveyId: string, userId: string) {
    for (const assignment of this.assignments.values()) {
      if (assignment.surveyId === surveyId && assignment.userId === userId) {
        return assignment;
      }
    }
    return null;
  }
}

export const storage = new MemoryStorage();