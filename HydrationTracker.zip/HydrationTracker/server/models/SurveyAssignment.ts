import mongoose, { Document, Schema } from 'mongoose';

export interface ISurveyAssignment extends Document {
  surveyId: mongoose.Types.ObjectId;
  userId: mongoose.Types.ObjectId;
  assignedBy: string;
  assignedAt: Date;
  status: 'pending' | 'in_progress' | 'completed';
  startedAt?: Date;
  completedAt?: Date;
  responses?: {
    questionId: string;
    answer: any;
    answeredAt: Date;
  }[];
  createdAt: Date;
  updatedAt: Date;
}

const ResponseSchema = new Schema({
  questionId: {
    type: String,
    required: true
  },
  answer: {
    type: Schema.Types.Mixed,
    required: true
  },
  answeredAt: {
    type: Date,
    default: Date.now
  }
}, { _id: false });

const SurveyAssignmentSchema = new Schema<ISurveyAssignment>({
  surveyId: {
    type: Schema.Types.ObjectId,
    ref: 'Survey',
    required: true
  },
  userId: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  assignedBy: {
    type: String,
    required: true,
    trim: true
  },
  assignedAt: {
    type: Date,
    default: Date.now
  },
  status: {
    type: String,
    enum: ['pending', 'in_progress', 'completed'],
    default: 'pending'
  },
  startedAt: Date,
  completedAt: Date,
  responses: [ResponseSchema]
}, {
  timestamps: true
});

// Indexes for better performance
SurveyAssignmentSchema.index({ surveyId: 1, userId: 1 }, { unique: true });
SurveyAssignmentSchema.index({ userId: 1 });
SurveyAssignmentSchema.index({ status: 1 });

export const SurveyAssignment = mongoose.model<ISurveyAssignment>('SurveyAssignment', SurveyAssignmentSchema);