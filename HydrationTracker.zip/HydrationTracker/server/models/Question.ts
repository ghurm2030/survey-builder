import mongoose, { Document, Schema } from 'mongoose';

export type QuestionType = 
  | 'numeric'
  | 'text'
  | 'single_choice'
  | 'multiple_choice'
  | 'date'
  | 'time'
  | 'phone';

export interface IQuestionOption {
  id: string;
  text: string;
  value: string;
}

export interface IQuestionValidation {
  min?: number;
  max?: number;
  pattern?: string;
  minLength?: number;
  maxLength?: number;
}

export interface IQuestion extends Document {
  surveyId: mongoose.Types.ObjectId;
  type: QuestionType;
  title: string;
  description?: string;
  required: boolean;
  order: number;
  options?: IQuestionOption[];
  validation?: IQuestionValidation;
  createdAt: Date;
  updatedAt: Date;
}

const QuestionOptionSchema = new Schema<IQuestionOption>({
  id: { type: String, required: true },
  text: { type: String, required: true, trim: true },
  value: { type: String, required: true, trim: true }
}, { _id: false });

const QuestionValidationSchema = new Schema<IQuestionValidation>({
  min: { type: Number },
  max: { type: Number },
  pattern: { type: String },
  minLength: { type: Number },
  maxLength: { type: Number }
}, { _id: false });

const QuestionSchema = new Schema<IQuestion>({
  surveyId: {
    type: Schema.Types.ObjectId,
    ref: 'Survey',
    required: true
  },
  type: {
    type: String,
    required: true,
    enum: ['numeric', 'text', 'single_choice', 'multiple_choice', 'date', 'time', 'phone']
  },
  title: {
    type: String,
    required: true,
    trim: true,
    minlength: 3
  },
  description: {
    type: String,
    trim: true
  },
  required: {
    type: Boolean,
    default: false
  },
  order: {
    type: Number,
    required: true,
    min: 1
  },
  options: [QuestionOptionSchema],
  validation: QuestionValidationSchema
}, {
  timestamps: true
});

// Indexes for better performance
QuestionSchema.index({ surveyId: 1, order: 1 });
QuestionSchema.index({ surveyId: 1 });

export const Question = mongoose.model<IQuestion>('Question', QuestionSchema);