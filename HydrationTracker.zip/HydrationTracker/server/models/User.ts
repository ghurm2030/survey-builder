import mongoose, { Document, Schema } from 'mongoose';

export type UserRole = 'admin' | 'user';
export type IdentifierType = 'name' | 'phone' | 'email';

export interface IUser extends Document {
  identifier: string;
  type: IdentifierType;
  role: UserRole;
  name?: string;
  email?: string;
  phone?: string;
  isActive: boolean;
  createdBy?: string;
  createdAt: Date;
  updatedAt: Date;
}

const UserSchema = new Schema<IUser>({
  identifier: {
    type: String,
    required: true,
    unique: true,
    trim: true
  },
  type: {
    type: String,
    required: true,
    enum: ['name', 'phone', 'email']
  },
  role: {
    type: String,
    required: true,
    enum: ['admin', 'user'],
    default: 'user'
  },
  name: {
    type: String,
    trim: true
  },
  email: {
    type: String,
    trim: true,
    lowercase: true
  },
  phone: {
    type: String,
    trim: true
  },
  isActive: {
    type: Boolean,
    default: true
  },
  createdBy: {
    type: String,
    trim: true
  }
}, {
  timestamps: true
});

// Indexes for better performance
UserSchema.index({ identifier: 1 });
UserSchema.index({ role: 1 });
UserSchema.index({ isActive: 1 });

export const User = mongoose.model<IUser>('User', UserSchema);