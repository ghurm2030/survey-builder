import mongoose, { Document, Schema } from 'mongoose';

export interface ISurvey extends Document {
  uniqueNumber: string;
  descriptionArabic: string;
  descriptionEnglish: string;
  startDateTime: Date;
  endDateTime: Date;
  createdBy: string;
  questionsCount?: number;
  createdAt: Date;
  updatedAt: Date;
}

const SurveySchema = new Schema<ISurvey>({
  uniqueNumber: {
    type: String,
    required: true,
    unique: true,
    trim: true
  },
  descriptionArabic: {
    type: String,
    required: true,
    trim: true,
    minlength: 10
  },
  descriptionEnglish: {
    type: String,
    required: true,
    trim: true,
    minlength: 10
  },
  startDateTime: {
    type: Date,
    required: true
  },
  endDateTime: {
    type: Date,
    required: true
  },
  createdBy: {
    type: String,
    required: true,
    trim: true
  }
}, {
  timestamps: true
});

// Indexes for better performance
SurveySchema.index({ uniqueNumber: 1 });
SurveySchema.index({ createdBy: 1 });
SurveySchema.index({ startDateTime: 1, endDateTime: 1 });

// Virtual for questions count
SurveySchema.virtual('questionsCount', {
  ref: 'Question',
  localField: '_id',
  foreignField: 'surveyId',
  count: true
});

// Ensure virtual fields are serialized
SurveySchema.set('toJSON', { virtuals: true });

export const Survey = mongoose.model<ISurvey>('Survey', SurveySchema);