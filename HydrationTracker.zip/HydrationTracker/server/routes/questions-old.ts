import express from 'express';
import { storage } from '../storage';

export const questionRoutes = express.Router();

// Create new question
questionRoutes.post('/', async (req, res) => {
  try {
    const { surveyId, type, title, description, required, options, validation } = req.body;

    // Validation
    if (!surveyId || !type || !title) {
      return res.status(400).json({
        message: 'الحقول المطلوبة: معرف الاستبيان، نوع السؤال، عنوان السؤال'
      });
    }

    // Check if survey exists
    const survey = await Survey.findById(surveyId);
    if (!survey) {
      return res.status(404).json({
        message: 'الاستبيان غير موجود'
      });
    }

    // Get current questions count to determine order
    const questionsCount = await Question.countDocuments({ surveyId: new mongoose.Types.ObjectId(surveyId) });
    const order = questionsCount + 1;

    // Prepare options with generated IDs
    const processedOptions = options?.map((opt: any, index: number) => ({
      id: `opt_${Date.now()}_${index}`,
      text: opt.text,
      value: opt.value
    }));

    // Create question
    const question = new Question({
      surveyId: new mongoose.Types.ObjectId(surveyId),
      type,
      title,
      description,
      required: required || false,
      order,
      options: processedOptions,
      validation
    });

    await question.save();

    res.status(201).json({
      success: true,
      question: {
        id: question._id,
        surveyId: question.surveyId,
        type: question.type,
        title: question.title,
        description: question.description,
        required: question.required,
        order: question.order,
        options: question.options,
        validation: question.validation,
        createdAt: question.createdAt
      }
    });

  } catch (error) {
    console.error('Create question error:', error);
    res.status(500).json({
      message: 'حدث خطأ أثناء إنشاء السؤال'
    });
  }
});

// Get questions by survey ID
questionRoutes.get('/survey/:surveyId', async (req, res) => {
  try {
    const { surveyId } = req.params;

    if (!mongoose.Types.ObjectId.isValid(surveyId)) {
      return res.status(400).json({
        message: 'معرف الاستبيان غير صالح'
      });
    }

    const questions = await Question.find({ surveyId: new mongoose.Types.ObjectId(surveyId) })
      .sort({ order: 1 });

    const processedQuestions = questions.map(question => ({
      id: question._id,
      surveyId: question.surveyId,
      type: question.type,
      title: question.title,
      description: question.description,
      required: question.required,
      order: question.order,
      options: question.options,
      validation: question.validation,
      createdAt: question.createdAt
    }));

    res.json({
      success: true,
      questions: processedQuestions
    });

  } catch (error) {
    console.error('Get questions error:', error);
    res.status(500).json({
      message: 'حدث خطأ أثناء جلب الأسئلة'
    });
  }
});

// Delete question
questionRoutes.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;

    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({
        message: 'معرف السؤال غير صالح'
      });
    }

    const question = await Question.findById(id);
    if (!question) {
      return res.status(404).json({
        message: 'السؤال غير موجود'
      });
    }

    // Delete the question
    await Question.findByIdAndDelete(id);

    // Update order of remaining questions
    await Question.updateMany(
      { 
        surveyId: question.surveyId, 
        order: { $gt: question.order } 
      },
      { $inc: { order: -1 } }
    );

    res.json({
      success: true,
      message: 'تم حذف السؤال بنجاح'
    });

  } catch (error) {
    console.error('Delete question error:', error);
    res.status(500).json({
      message: 'حدث خطأ أثناء حذف السؤال'
    });
  }
});

// Update question order
questionRoutes.patch('/:id/order', async (req, res) => {
  try {
    const { id } = req.params;
    const { newOrder } = req.body;

    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({
        message: 'معرف السؤال غير صالح'
      });
    }

    if (!newOrder || newOrder < 1) {
      return res.status(400).json({
        message: 'ترتيب السؤال يجب أن يكون رقماً موجباً'
      });
    }

    const question = await Question.findById(id);
    if (!question) {
      return res.status(404).json({
        message: 'السؤال غير موجود'
      });
    }

    const oldOrder = question.order;
    
    // Update other questions' orders
    if (newOrder > oldOrder) {
      // Moving down
      await Question.updateMany(
        {
          surveyId: question.surveyId,
          order: { $gt: oldOrder, $lte: newOrder }
        },
        { $inc: { order: -1 } }
      );
    } else if (newOrder < oldOrder) {
      // Moving up
      await Question.updateMany(
        {
          surveyId: question.surveyId,
          order: { $gte: newOrder, $lt: oldOrder }
        },
        { $inc: { order: 1 } }
      );
    }

    // Update the question's order
    question.order = newOrder;
    await question.save();

    res.json({
      success: true,
      message: 'تم تحديث ترتيب السؤال بنجاح'
    });

  } catch (error) {
    console.error('Update question order error:', error);
    res.status(500).json({
      message: 'حدث خطأ أثناء تحديث ترتيب السؤال'
    });
  }
});

// Get questions count for a survey
questionRoutes.get('/survey/:surveyId/count', async (req, res) => {
  try {
    const { surveyId } = req.params;

    if (!mongoose.Types.ObjectId.isValid(surveyId)) {
      return res.status(400).json({
        message: 'معرف الاستبيان غير صالح'
      });
    }

    const count = await Question.countDocuments({ surveyId: new mongoose.Types.ObjectId(surveyId) });

    res.json({
      success: true,
      count
    });

  } catch (error) {
    console.error('Get questions count error:', error);
    res.status(500).json({
      message: 'حدث خطأ أثناء جلب عدد الأسئلة'
    });
  }
});