import express from 'express';
import { storage } from '../storage';

export const userRoutes = express.Router();

// Helper function to determine identifier type
const determineIdentifierType = (identifier: string): 'name' | 'phone' | 'email' => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const phoneRegex = /^[\+]?[0-9\s\-\(\)]{7,15}$/;
  
  if (emailRegex.test(identifier)) {
    return 'email';
  } else if (phoneRegex.test(identifier)) {
    return 'phone';
  } else {
    return 'name';
  }
};

// Create new user (Admin only)
userRoutes.post('/', async (req, res) => {
  try {
    const { identifier, role, name, email, phone, createdBy } = req.body;

    // Validation
    if (!identifier || !role || !createdBy) {
      return res.status(400).json({
        message: 'المعرف والدور ومنشئ المستخدم مطلوبة'
      });
    }

    if (!['admin', 'user'].includes(role)) {
      return res.status(400).json({
        message: 'دور المستخدم يجب أن يكون admin أو user'
      });
    }

    // Check if user already exists
    const existingUser = await storage.findUserByIdentifier(identifier.trim());
    if (existingUser) {
      return res.status(400).json({
        message: 'المستخدم موجود مسبقاً'
      });
    }

    const type = determineIdentifierType(identifier.trim());

    // Create user
    const user = await storage.createUser({
      identifier: identifier.trim(),
      type,
      role,
      name: name?.trim(),
      email: email?.trim(),
      phone: phone?.trim(),
      createdBy: createdBy.trim(),
      isActive: true
    });

    res.status(201).json({
      success: true,
      user: {
        id: user._id,
        identifier: user.identifier,
        type: user.type,
        role: user.role,
        name: user.name,
        email: user.email,
        phone: user.phone,
        isActive: user.isActive,
        createdBy: user.createdBy,
        createdAt: user.createdAt
      }
    });

  } catch (error) {
    console.error('Create user error:', error);
    res.status(500).json({
      message: 'حدث خطأ أثناء إنشاء المستخدم'
    });
  }
});

// Get all users (Admin only)
userRoutes.get('/', async (req, res) => {
  try {
    const { role, isActive } = req.query;
    
    const filter: any = {};
    if (role) filter.role = role;
    if (isActive !== undefined) filter.isActive = isActive === 'true';

    const users = await storage.getAllUsers(filter);

    const processedUsers = users.map(user => ({
      id: user._id,
      identifier: user.identifier,
      type: user.type,
      role: user.role,
      name: user.name,
      email: user.email,
      phone: user.phone,
      isActive: user.isActive,
      createdBy: user.createdBy,
      createdAt: user.createdAt
    }));

    res.json({
      success: true,
      users: processedUsers
    });

  } catch (error) {
    console.error('Get users error:', error);
    res.status(500).json({
      message: 'حدث خطأ أثناء جلب المستخدمين'
    });
  }
});

// Get user by ID
userRoutes.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;

    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({
        message: 'معرف المستخدم غير صالح'
      });
    }

    const user = await User.findById(id).select('-__v');
    
    if (!user) {
      return res.status(404).json({
        message: 'المستخدم غير موجود'
      });
    }

    res.json({
      success: true,
      user: {
        id: user._id,
        identifier: user.identifier,
        type: user.type,
        role: user.role,
        name: user.name,
        email: user.email,
        phone: user.phone,
        isActive: user.isActive,
        createdBy: user.createdBy,
        createdAt: user.createdAt
      }
    });

  } catch (error) {
    console.error('Get user error:', error);
    res.status(500).json({
      message: 'حدث خطأ أثناء جلب المستخدم'
    });
  }
});

// Update user (Admin only)
userRoutes.patch('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { name, email, phone, role, isActive } = req.body;

    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({
        message: 'معرف المستخدم غير صالح'
      });
    }

    const updateData: any = {};
    if (name !== undefined) updateData.name = name?.trim();
    if (email !== undefined) updateData.email = email?.trim();
    if (phone !== undefined) updateData.phone = phone?.trim();
    if (role !== undefined) {
      if (!['admin', 'user'].includes(role)) {
        return res.status(400).json({
          message: 'دور المستخدم يجب أن يكون admin أو user'
        });
      }
      updateData.role = role;
    }
    if (isActive !== undefined) updateData.isActive = isActive;

    const user = await User.findByIdAndUpdate(
      id,
      updateData,
      { new: true, runValidators: true }
    ).select('-__v');

    if (!user) {
      return res.status(404).json({
        message: 'المستخدم غير موجود'
      });
    }

    res.json({
      success: true,
      user: {
        id: user._id,
        identifier: user.identifier,
        type: user.type,
        role: user.role,
        name: user.name,
        email: user.email,
        phone: user.phone,
        isActive: user.isActive,
        createdBy: user.createdBy,
        createdAt: user.createdAt
      }
    });

  } catch (error) {
    console.error('Update user error:', error);
    res.status(500).json({
      message: 'حدث خطأ أثناء تحديث المستخدم'
    });
  }
});

// Delete user (Admin only)
userRoutes.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;

    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({
        message: 'معرف المستخدم غير صالح'
      });
    }

    const user = await User.findByIdAndDelete(id);

    if (!user) {
      return res.status(404).json({
        message: 'المستخدم غير موجود'
      });
    }

    // Also delete related survey assignments
    await SurveyAssignment.deleteMany({ userId: new mongoose.Types.ObjectId(id) });

    res.json({
      success: true,
      message: 'تم حذف المستخدم بنجاح'
    });

  } catch (error) {
    console.error('Delete user error:', error);
    res.status(500).json({
      message: 'حدث خطأ أثناء حذف المستخدم'
    });
  }
});

// Assign survey to user(s) (Admin only)
userRoutes.post('/assign-survey', async (req, res) => {
  try {
    const { surveyId, userIds, assignedBy } = req.body;

    // Validation
    if (!surveyId || !userIds || !Array.isArray(userIds) || userIds.length === 0 || !assignedBy) {
      return res.status(400).json({
        message: 'معرف الاستبيان وقائمة المستخدمين ومعين الاستبيان مطلوبة'
      });
    }

    if (!mongoose.Types.ObjectId.isValid(surveyId)) {
      return res.status(400).json({
        message: 'معرف الاستبيان غير صالح'
      });
    }

    // Validate user IDs
    const invalidUserIds = userIds.filter(id => !mongoose.Types.ObjectId.isValid(id));
    if (invalidUserIds.length > 0) {
      return res.status(400).json({
        message: 'بعض معرفات المستخدمين غير صالحة'
      });
    }

    // Create assignments
    const assignments = [];
    const errors = [];

    for (const userId of userIds) {
      try {
        // Check if assignment already exists
        const existingAssignment = await SurveyAssignment.findOne({
          surveyId: new mongoose.Types.ObjectId(surveyId),
          userId: new mongoose.Types.ObjectId(userId)
        });

        if (existingAssignment) {
          errors.push(`المستخدم ${userId} مُعين للاستبيان مسبقاً`);
          continue;
        }

        const assignment = new SurveyAssignment({
          surveyId: new mongoose.Types.ObjectId(surveyId),
          userId: new mongoose.Types.ObjectId(userId),
          assignedBy: assignedBy.trim()
        });

        await assignment.save();
        assignments.push({
          id: assignment._id,
          surveyId: assignment.surveyId,
          userId: assignment.userId,
          status: assignment.status,
          assignedAt: assignment.assignedAt
        });

      } catch (error) {
        errors.push(`خطأ في تعيين المستخدم ${userId}: ${error.message}`);
      }
    }

    res.json({
      success: true,
      assignments,
      errors: errors.length > 0 ? errors : undefined,
      message: `تم تعيين الاستبيان لـ ${assignments.length} من ${userIds.length} مستخدم`
    });

  } catch (error) {
    console.error('Assign survey error:', error);
    res.status(500).json({
      message: 'حدث خطأ أثناء تعيين الاستبيان'
    });
  }
});

// Get user assignments
userRoutes.get('/:userId/assignments', async (req, res) => {
  try {
    const { userId } = req.params;
    const { status } = req.query;

    if (!mongoose.Types.ObjectId.isValid(userId)) {
      return res.status(400).json({
        message: 'معرف المستخدم غير صالح'
      });
    }

    const filter: any = { userId: new mongoose.Types.ObjectId(userId) };
    if (status) filter.status = status;

    const assignments = await SurveyAssignment.find(filter)
      .populate('surveyId', 'uniqueNumber descriptionArabic startDateTime endDateTime')
      .sort({ assignedAt: -1 });

    const processedAssignments = assignments.map(assignment => ({
      id: assignment._id,
      survey: assignment.surveyId,
      status: assignment.status,
      assignedAt: assignment.assignedAt,
      startedAt: assignment.startedAt,
      completedAt: assignment.completedAt,
      responsesCount: assignment.responses?.length || 0
    }));

    res.json({
      success: true,
      assignments: processedAssignments
    });

  } catch (error) {
    console.error('Get user assignments error:', error);
    res.status(500).json({
      message: 'حدث خطأ أثناء جلب تعيينات المستخدم'
    });
  }
});