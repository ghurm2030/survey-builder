import express from 'express';
import { storage } from '../storage';

export const surveyRoutes = express.Router();

// Create new survey
surveyRoutes.post('/', async (req, res) => {
  try {
    const { uniqueNumber, descriptionArabic, descriptionEnglish, startDateTime, endDateTime, createdBy } = req.body;

    // Validation
    if (!uniqueNumber || !descriptionArabic || !descriptionEnglish || !startDateTime || !endDateTime || !createdBy) {
      return res.status(400).json({
        message: 'جميع الحقول مطلوبة'
      });
    }

    // Check if unique number already exists
    const existingSurvey = await storage.findSurveyByUniqueNumber(uniqueNumber);
    if (existingSurvey) {
      return res.status(400).json({
        message: 'رقم الاستبيان موجود مسبقاً'
      });
    }

    // Validate dates
    const start = new Date(startDateTime);
    const end = new Date(endDateTime);
    
    if (start >= end) {
      return res.status(400).json({
        message: 'تاريخ البداية يجب أن يكون قبل تاريخ النهاية'
      });
    }

    // Create survey
    const survey = new Survey({
      uniqueNumber,
      descriptionArabic,
      descriptionEnglish,
      startDateTime: start,
      endDateTime: end,
      createdBy
    });

    await survey.save();

    res.status(201).json({
      success: true,
      survey: {
        id: survey._id,
        uniqueNumber: survey.uniqueNumber,
        descriptionArabic: survey.descriptionArabic,
        descriptionEnglish: survey.descriptionEnglish,
        startDateTime: survey.startDateTime,
        endDateTime: survey.endDateTime,
        createdBy: survey.createdBy,
        createdAt: survey.createdAt
      }
    });

  } catch (error) {
    console.error('Create survey error:', error);
    res.status(500).json({
      message: 'حدث خطأ أثناء إنشاء الاستبيان'
    });
  }
});

// Get surveys by creator
surveyRoutes.get('/user/:createdBy', async (req, res) => {
  try {
    const { createdBy } = req.params;

    if (!createdBy) {
      return res.status(400).json({
        message: 'معرف المستخدم مطلوب'
      });
    }

    const surveys = await Survey.find({ createdBy: decodeURIComponent(createdBy) })
      .sort({ createdAt: -1 });

    // Get questions count for each survey
    const surveysWithQuestionCount = await Promise.all(
      surveys.map(async (survey) => {
        const questionsCount = await Question.countDocuments({ surveyId: survey._id });
        return {
          id: survey._id,
          uniqueNumber: survey.uniqueNumber,
          descriptionArabic: survey.descriptionArabic,
          descriptionEnglish: survey.descriptionEnglish,
          startDateTime: survey.startDateTime,
          endDateTime: survey.endDateTime,
          createdBy: survey.createdBy,
          createdAt: survey.createdAt,
          questionsCount
        };
      })
    );

    res.json({
      success: true,
      surveys: surveysWithQuestionCount
    });

  } catch (error) {
    console.error('Get surveys error:', error);
    res.status(500).json({
      message: 'حدث خطأ أثناء جلب الاستبيانات'
    });
  }
});

// Get survey by ID
surveyRoutes.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;

    const survey = await Survey.findById(id);
    
    if (!survey) {
      return res.status(404).json({
        message: 'الاستبيان غير موجود'
      });
    }

    const questionsCount = await Question.countDocuments({ surveyId: survey._id });

    res.json({
      success: true,
      survey: {
        id: survey._id,
        uniqueNumber: survey.uniqueNumber,
        descriptionArabic: survey.descriptionArabic,
        descriptionEnglish: survey.descriptionEnglish,
        startDateTime: survey.startDateTime,
        endDateTime: survey.endDateTime,
        createdBy: survey.createdBy,
        createdAt: survey.createdAt,
        questionsCount
      }
    });

  } catch (error) {
    console.error('Get survey error:', error);
    res.status(500).json({
      message: 'حدث خطأ أثناء جلب الاستبيان'
    });
  }
});

// Generate unique number
surveyRoutes.get('/utils/generate-number', (req, res) => {
  const timestamp = Date.now().toString().slice(-6);
  const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
  const uniqueNumber = `SV${timestamp}${random}`;

  res.json({
    success: true,
    uniqueNumber
  });
});