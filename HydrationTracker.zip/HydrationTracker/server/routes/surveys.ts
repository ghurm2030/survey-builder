import express from 'express';
import { storage } from '../storage';

export const surveyRoutes = express.Router();

// Create new survey
surveyRoutes.post('/', async (req, res) => {
  try {
    const { uniqueNumber, descriptionArabic, descriptionEnglish, startDateTime, endDateTime, createdBy } = req.body;

    if (!uniqueNumber || !descriptionArabic || !descriptionEnglish || !startDateTime || !endDateTime || !createdBy) {
      return res.status(400).json({
        message: 'جميع الحقول مطلوبة'
      });
    }

    const existingSurvey = await storage.findSurveyByUniqueNumber(uniqueNumber);
    if (existingSurvey) {
      return res.status(400).json({
        message: 'رقم الاستبيان موجود مسبقاً'
      });
    }

    const survey = await storage.createSurvey({
      uniqueNumber,
      descriptionArabic,
      descriptionEnglish,
      startDateTime: new Date(startDateTime),
      endDateTime: new Date(endDateTime),
      createdBy
    });

    res.status(201).json({
      success: true,
      survey: {
        id: survey._id,
        uniqueNumber: survey.uniqueNumber,
        descriptionArabic: survey.descriptionArabic,
        descriptionEnglish: survey.descriptionEnglish,
        startDateTime: survey.startDateTime,
        endDateTime: survey.endDateTime,
        createdAt: survey.createdAt,
        createdBy: survey.createdBy
      }
    });

  } catch (error) {
    console.error('Create survey error:', error);
    res.status(500).json({
      message: 'حدث خطأ أثناء إنشاء الاستبيان'
    });
  }
});

// Get surveys by creator
surveyRoutes.get('/user/:createdBy', async (req, res) => {
  try {
    const { createdBy } = req.params;

    const surveys = await storage.getSurveysByCreator(createdBy);

    const surveysWithQuestions = await Promise.all(
      surveys.map(async (survey) => {
        const questions = await storage.getQuestionsBySurveyId(survey._id);
        return {
          id: survey._id,
          uniqueNumber: survey.uniqueNumber,
          descriptionArabic: survey.descriptionArabic,
          descriptionEnglish: survey.descriptionEnglish,
          startDateTime: survey.startDateTime,
          endDateTime: survey.endDateTime,
          createdAt: survey.createdAt,
          createdBy: survey.createdBy,
          questionsCount: questions.length
        };
      })
    );

    res.json({
      success: true,
      surveys: surveysWithQuestions
    });

  } catch (error) {
    console.error('Get surveys error:', error);
    res.status(500).json({
      message: 'حدث خطأ أثناء جلب الاستبيانات'
    });
  }
});

// Generate unique number
surveyRoutes.get('/generate-unique-number', async (req, res) => {
  try {
    let uniqueNumber;
    let exists = true;
    
    while (exists) {
      uniqueNumber = 'SUR' + Date.now() + Math.floor(Math.random() * 1000);
      const existingSurvey = await storage.findSurveyByUniqueNumber(uniqueNumber);
      exists = !!existingSurvey;
    }

    res.json({
      success: true,
      uniqueNumber
    });

  } catch (error) {
    console.error('Generate unique number error:', error);
    res.status(500).json({
      message: 'حدث خطأ أثناء إنشاء الرقم الفريد'
    });
  }
});