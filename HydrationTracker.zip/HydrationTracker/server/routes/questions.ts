import express from 'express';
import { storage } from '../storage';

export const questionRoutes = express.Router();

// Create new question
questionRoutes.post('/', async (req, res) => {
  try {
    const { surveyId, type, title, description, required, options, validation } = req.body;

    if (!surveyId || !type || !title) {
      return res.status(400).json({
        message: 'الحقول المطلوبة: معرف الاستبيان، نوع السؤال، عنوان السؤال'
      });
    }

    const existingQuestions = await storage.getQuestionsBySurveyId(surveyId);
    const order = existingQuestions.length + 1;

    const question = await storage.createQuestion({
      surveyId,
      type,
      title,
      description,
      required: required || false,
      order,
      options: options || [],
      validation: validation || {}
    });

    res.status(201).json({
      success: true,
      question: {
        id: question._id,
        surveyId: question.surveyId,
        type: question.type,
        title: question.title,
        description: question.description,
        required: question.required,
        order: question.order,
        options: question.options,
        validation: question.validation,
        createdAt: question.createdAt
      }
    });

  } catch (error) {
    console.error('Create question error:', error);
    res.status(500).json({
      message: 'حدث خطأ أثناء إنشاء السؤال'
    });
  }
});

// Get questions by survey ID
questionRoutes.get('/survey/:surveyId', async (req, res) => {
  try {
    const { surveyId } = req.params;

    const questions = await storage.getQuestionsBySurveyId(surveyId);

    const processedQuestions = questions.map(question => ({
      id: question._id,
      surveyId: question.surveyId,
      type: question.type,
      title: question.title,
      description: question.description,
      required: question.required,
      order: question.order,
      options: question.options,
      validation: question.validation,
      createdAt: question.createdAt
    }));

    res.json({
      success: true,
      questions: processedQuestions
    });

  } catch (error) {
    console.error('Get questions error:', error);
    res.status(500).json({
      message: 'حدث خطأ أثناء جلب الأسئلة'
    });
  }
});

// Delete question
questionRoutes.delete('/:questionId', async (req, res) => {
  try {
    const { questionId } = req.params;

    const deleted = await storage.deleteQuestion(questionId);

    if (!deleted) {
      return res.status(404).json({
        message: 'السؤال غير موجود'
      });
    }

    res.json({
      success: true,
      message: 'تم حذف السؤال بنجاح'
    });

  } catch (error) {
    console.error('Delete question error:', error);
    res.status(500).json({
      message: 'حدث خطأ أثناء حذف السؤال'
    });
  }
});

// Update question order
questionRoutes.patch('/:questionId/order', async (req, res) => {
  try {
    const { questionId } = req.params;
    const { newOrder } = req.body;

    if (!newOrder || newOrder < 1) {
      return res.status(400).json({
        message: 'ترتيب السؤال يجب أن يكون رقم موجب'
      });
    }

    const updatedQuestion = await storage.updateQuestion(questionId, { order: newOrder });

    if (!updatedQuestion) {
      return res.status(404).json({
        message: 'السؤال غير موجود'
      });
    }

    res.json({
      success: true,
      question: {
        id: updatedQuestion._id,
        order: updatedQuestion.order
      }
    });

  } catch (error) {
    console.error('Update question order error:', error);
    res.status(500).json({
      message: 'حدث خطأ أثناء تحديث ترتيب السؤال'
    });
  }
});