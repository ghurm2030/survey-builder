import express from 'express';
import { storage } from '../storage';

export const authRoutes = express.Router();

// Helper function to determine identifier type
const determineIdentifierType = (identifier: string): 'name' | 'phone' | 'email' => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const phoneRegex = /^[\+]?[0-9\s\-\(\)]{7,15}$/;
  
  if (emailRegex.test(identifier)) {
    return 'email';
  } else if (phoneRegex.test(identifier)) {
    return 'phone';
  } else {
    return 'name';
  }
};

// Login endpoint
authRoutes.post('/login', async (req, res) => {
  try {
    const { identifier } = req.body;

    if (!identifier || typeof identifier !== 'string' || identifier.trim().length < 3) {
      return res.status(400).json({
        message: 'يجب إدخال اسم صالح أو رقم جوال أو بريد إلكتروني'
      });
    }

    const trimmedIdentifier = identifier.trim();
    const type = determineIdentifierType(trimmedIdentifier);

    // Find user (no auto-creation for login)
    let user = await storage.findUserByIdentifier(trimmedIdentifier);
    
    if (!user || !user.isActive) {
      return res.status(401).json({
        message: 'المستخدم غير موجود أو غير مفعل'
      });
    }

    // Return user data
    res.json({
      success: true,
      user: {
        id: user._id,
        identifier: user.identifier,
        type: user.type,
        role: user.role,
        name: user.name,
        email: user.email,
        phone: user.phone,
        createdAt: user.createdAt
      }
    });

  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({
      message: 'حدث خطأ أثناء تسجيل الدخول'
    });
  }
});

// Get current user
authRoutes.get('/user/:identifier', async (req, res) => {
  try {
    const { identifier } = req.params;

    if (!identifier) {
      return res.status(400).json({
        message: 'المعرف مطلوب'
      });
    }

    const user = await User.findOne({ identifier: decodeURIComponent(identifier) });
    
    if (!user) {
      return res.status(404).json({
        message: 'المستخدم غير موجود'
      });
    }

    res.json({
      id: user._id,
      identifier: user.identifier,
      type: user.type,
      createdAt: user.createdAt
    });

  } catch (error) {
    console.error('Get user error:', error);
    res.status(500).json({
      message: 'حدث خطأ أثناء جلب بيانات المستخدم'
    });
  }
});