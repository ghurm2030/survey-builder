import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { CreateSurveyComponent } from './components/create-survey/create-survey.component';
import { SurveysListComponent } from './components/surveys-list/surveys-list.component';
import { UsersManagementComponent } from './components/users-management/users-management.component';
import { ExcelUploadComponent } from './components/excel-upload/excel-upload.component';
import { TemplateGeneratorComponent } from './components/template-generator/template-generator.component';
import { AuthGuard } from './services/auth.guard';

const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'dashboard', component: DashboardComponent, canActivate: [AuthGuard] },
  { path: 'create-survey', component: CreateSurveyComponent, canActivate: [AuthGuard] },
  { path: 'surveys', component: SurveysListComponent, canActivate: [AuthGuard] },
  { path: 'users', component: UsersManagementComponent, canActivate: [AuthGuard] },
  { path: 'excel-upload', component: ExcelUploadComponent, canActivate: [AuthGuard] },
  { path: 'template-generator', component: TemplateGeneratorComponent, canActivate: [AuthGuard] },
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: '**', redirectTo: '/login' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }