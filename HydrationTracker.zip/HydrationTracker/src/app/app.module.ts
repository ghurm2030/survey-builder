import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { CreateSurveyComponent } from './components/create-survey/create-survey.component';
import { SurveysListComponent } from './components/surveys-list/surveys-list.component';
import { QuestionFormComponent } from './components/question-form/question-form.component';
import { QuestionsListComponent } from './components/questions-list/questions-list.component';
import { UsersManagementComponent } from './components/users-management/users-management.component';
import { ExcelUploadComponent } from './components/excel-upload/excel-upload.component';
import { TemplateGeneratorComponent } from './components/template-generator/template-generator.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DashboardComponent,
    CreateSurveyComponent,
    SurveysListComponent,
    QuestionFormComponent,
    QuestionsListComponent,
    UsersManagementComponent,
    ExcelUploadComponent,
    TemplateGeneratorComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    BrowserAnimationsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }