export interface Survey {
  id: string;
  uniqueNumber: string;
  descriptionArabic: string;
  descriptionEnglish: string;
  startDateTime: Date;
  endDateTime: Date;
  createdAt: Date;
  createdBy: string;
  questionsCount?: number;
}

export interface CreateSurveyRequest {
  uniqueNumber: string;
  descriptionArabic: string;
  descriptionEnglish: string;
  startDateTime: Date;
  endDateTime: Date;
}