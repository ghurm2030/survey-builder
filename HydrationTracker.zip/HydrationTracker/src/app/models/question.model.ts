export type QuestionType = 
  | 'numeric'       // سؤال رقمي
  | 'text'          // سؤال نصي
  | 'single_choice' // اختيار واحد
  | 'multiple_choice' // اختيار متعدد
  | 'date'          // تاريخ
  | 'time'          // وقت
  | 'phone';        // رقم الجوال

export interface QuestionOption {
  id: string;
  text: string;
  value: string;
}

export interface Question {
  id: string;
  surveyId: string;
  type: QuestionType;
  title: string;
  description?: string;
  required: boolean;
  order: number;
  options?: QuestionOption[]; // للاختيارات
  validation?: {
    min?: number;
    max?: number;
    pattern?: string;
    minLength?: number;
    maxLength?: number;
  };
}

export interface CreateQuestionRequest {
  type: QuestionType;
  title: string;
  description?: string;
  required: boolean;
  options?: Omit<QuestionOption, 'id'>[];
  validation?: Question['validation'];
}

export const QUESTION_TYPES: { [key in QuestionType]: string } = {
  numeric: 'سؤال رقمي',
  text: 'سؤال نصي',
  single_choice: 'اختيار واحد',
  multiple_choice: 'اختيار متعدد',
  date: 'سؤال تاريخ',
  time: 'سؤال وقت',
  phone: 'رقم الجوال'
};