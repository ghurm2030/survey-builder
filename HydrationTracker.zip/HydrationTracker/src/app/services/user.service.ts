import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { of } from 'rxjs';

export interface CreateUserRequest {
  identifier: string;
  role: 'admin' | 'user';
  name?: string;
  email?: string;
  phone?: string;
}

export interface UserDetails {
  id: string;
  identifier: string;
  type: 'name' | 'phone' | 'email';
  role: 'admin' | 'user';
  name?: string;
  email?: string;
  phone?: string;
  isActive: boolean;
  createdBy?: string;
  createdAt: Date;
}

export interface SurveyAssignment {
  id: string;
  survey: {
    uniqueNumber: string;
    descriptionArabic: string;
    startDateTime: Date;
    endDateTime: Date;
  };
  status: 'pending' | 'in_progress' | 'completed';
  assignedAt: Date;
  startedAt?: Date;
  completedAt?: Date;
  responsesCount: number;
}

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private apiUrl = 'http://localhost:3000/api';

  constructor(private http: HttpClient) {}

  createUser(userData: CreateUserRequest, createdBy: string): Observable<UserDetails> {
    const payload = {
      ...userData,
      createdBy
    };

    return this.http.post<any>(`${this.apiUrl}/users`, payload).pipe(
      map(response => {
        if (response.success && response.user) {
          return {
            id: response.user.id,
            identifier: response.user.identifier,
            type: response.user.type,
            role: response.user.role,
            name: response.user.name,
            email: response.user.email,
            phone: response.user.phone,
            isActive: response.user.isActive,
            createdBy: response.user.createdBy,
            createdAt: new Date(response.user.createdAt)
          };
        }
        throw new Error('فشل في إنشاء المستخدم');
      }),
      catchError(error => {
        console.error('Create user error:', error);
        const errorMessage = error.error?.message || 'حدث خطأ أثناء إنشاء المستخدم';
        throw new Error(errorMessage);
      })
    );
  }

  getUsers(role?: 'admin' | 'user', isActive?: boolean): Observable<UserDetails[]> {
    let url = `${this.apiUrl}/users`;
    const params = new URLSearchParams();
    
    if (role) params.append('role', role);
    if (isActive !== undefined) params.append('isActive', isActive.toString());
    
    if (params.toString()) {
      url += `?${params.toString()}`;
    }

    return this.http.get<any>(url).pipe(
      map(response => {
        if (response.success && response.users) {
          return response.users.map((user: any) => ({
            id: user.id,
            identifier: user.identifier,
            type: user.type,
            role: user.role,
            name: user.name,
            email: user.email,
            phone: user.phone,
            isActive: user.isActive,
            createdBy: user.createdBy,
            createdAt: new Date(user.createdAt)
          }));
        }
        return [];
      }),
      catchError(error => {
        console.error('Get users error:', error);
        return of([]);
      })
    );
  }

  getUserById(id: string): Observable<UserDetails | null> {
    return this.http.get<any>(`${this.apiUrl}/users/${id}`).pipe(
      map(response => {
        if (response.success && response.user) {
          return {
            id: response.user.id,
            identifier: response.user.identifier,
            type: response.user.type,
            role: response.user.role,
            name: response.user.name,
            email: response.user.email,
            phone: response.user.phone,
            isActive: response.user.isActive,
            createdBy: response.user.createdBy,
            createdAt: new Date(response.user.createdAt)
          };
        }
        return null;
      }),
      catchError(error => {
        console.error('Get user error:', error);
        return of(null);
      })
    );
  }

  updateUser(id: string, updateData: Partial<UserDetails>): Observable<UserDetails> {
    return this.http.patch<any>(`${this.apiUrl}/users/${id}`, updateData).pipe(
      map(response => {
        if (response.success && response.user) {
          return {
            id: response.user.id,
            identifier: response.user.identifier,
            type: response.user.type,
            role: response.user.role,
            name: response.user.name,
            email: response.user.email,
            phone: response.user.phone,
            isActive: response.user.isActive,
            createdBy: response.user.createdBy,
            createdAt: new Date(response.user.createdAt)
          };
        }
        throw new Error('فشل في تحديث المستخدم');
      }),
      catchError(error => {
        console.error('Update user error:', error);
        const errorMessage = error.error?.message || 'حدث خطأ أثناء تحديث المستخدم';
        throw new Error(errorMessage);
      })
    );
  }

  deleteUser(id: string): Observable<boolean> {
    return this.http.delete<any>(`${this.apiUrl}/users/${id}`).pipe(
      map(response => response.success || false),
      catchError(error => {
        console.error('Delete user error:', error);
        return of(false);
      })
    );
  }

  assignSurveyToUsers(surveyId: string, userIds: string[], assignedBy: string): Observable<any> {
    const payload = {
      surveyId,
      userIds,
      assignedBy
    };

    return this.http.post<any>(`${this.apiUrl}/users/assign-survey`, payload).pipe(
      map(response => response),
      catchError(error => {
        console.error('Assign survey error:', error);
        const errorMessage = error.error?.message || 'حدث خطأ أثناء تعيين الاستبيان';
        throw new Error(errorMessage);
      })
    );
  }

  getUserAssignments(userId: string, status?: string): Observable<SurveyAssignment[]> {
    let url = `${this.apiUrl}/users/${userId}/assignments`;
    if (status) {
      url += `?status=${status}`;
    }

    return this.http.get<any>(url).pipe(
      map(response => {
        if (response.success && response.assignments) {
          return response.assignments.map((assignment: any) => ({
            id: assignment.id,
            survey: {
              uniqueNumber: assignment.survey.uniqueNumber,
              descriptionArabic: assignment.survey.descriptionArabic,
              startDateTime: new Date(assignment.survey.startDateTime),
              endDateTime: new Date(assignment.survey.endDateTime)
            },
            status: assignment.status,
            assignedAt: new Date(assignment.assignedAt),
            startedAt: assignment.startedAt ? new Date(assignment.startedAt) : undefined,
            completedAt: assignment.completedAt ? new Date(assignment.completedAt) : undefined,
            responsesCount: assignment.responsesCount
          }));
        }
        return [];
      }),
      catchError(error => {
        console.error('Get user assignments error:', error);
        return of([]);
      })
    );
  }
}