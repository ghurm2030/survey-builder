import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { map, catchError } from 'rxjs/operators';
import { of } from 'rxjs';
import { Survey, CreateSurveyRequest } from '../models/survey.model';

@Injectable({
  providedIn: 'root'
})
export class SurveyService {
  private apiUrl = 'http://localhost:3000/api';
  private surveysSubject = new BehaviorSubject<Survey[]>([]);
  public surveys$ = this.surveysSubject.asObservable();

  constructor(private http: HttpClient) {}

  createSurvey(surveyData: CreateSurveyRequest, createdBy: string): Observable<Survey> {
    const payload = {
      ...surveyData,
      createdBy
    };

    return this.http.post<any>(`${this.apiUrl}/surveys`, payload).pipe(
      map(response => {
        if (response.success && response.survey) {
          const survey: Survey = {
            id: response.survey.id,
            uniqueNumber: response.survey.uniqueNumber,
            descriptionArabic: response.survey.descriptionArabic,
            descriptionEnglish: response.survey.descriptionEnglish,
            startDateTime: new Date(response.survey.startDateTime),
            endDateTime: new Date(response.survey.endDateTime),
            createdAt: new Date(response.survey.createdAt),
            createdBy: response.survey.createdBy
          };
          
          // Update local state
          const currentSurveys = this.surveysSubject.value;
          this.surveysSubject.next([...currentSurveys, survey]);
          
          return survey;
        }
        throw new Error('فشل في إنشاء الاستبيان');
      }),
      catchError(error => {
        console.error('Create survey error:', error);
        const errorMessage = error.error?.message || 'حدث خطأ أثناء إنشاء الاستبيان';
        throw new Error(errorMessage);
      })
    );
  }

  loadSurveysByUser(createdBy: string): Observable<Survey[]> {
    return this.http.get<any>(`${this.apiUrl}/surveys/user/${encodeURIComponent(createdBy)}`).pipe(
      map(response => {
        if (response.success && response.surveys) {
          const surveys = response.surveys.map((survey: any) => ({
            id: survey.id,
            uniqueNumber: survey.uniqueNumber,
            descriptionArabic: survey.descriptionArabic,
            descriptionEnglish: survey.descriptionEnglish,
            startDateTime: new Date(survey.startDateTime),
            endDateTime: new Date(survey.endDateTime),
            createdAt: new Date(survey.createdAt),
            createdBy: survey.createdBy,
            questionsCount: survey.questionsCount
          }));
          
          this.surveysSubject.next(surveys);
          return surveys;
        }
        return [];
      }),
      catchError(error => {
        console.error('Load surveys error:', error);
        return of([]);
      })
    );
  }

  getSurveys(): Survey[] {
    return this.surveysSubject.value;
  }

  getSurveyByUniqueNumber(uniqueNumber: string): Survey | undefined {
    return this.surveysSubject.value.find(s => s.uniqueNumber === uniqueNumber);
  }

  generateUniqueNumber(): Observable<string> {
    return this.http.get<any>(`${this.apiUrl}/surveys/utils/generate-number`).pipe(
      map(response => {
        if (response.success && response.uniqueNumber) {
          return response.uniqueNumber;
        }
        // Fallback to local generation
        const timestamp = Date.now().toString().slice(-6);
        const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
        return `SV${timestamp}${random}`;
      }),
      catchError(() => {
        // Fallback to local generation
        const timestamp = Date.now().toString().slice(-6);
        const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
        return of(`SV${timestamp}${random}`);
      })
    );
  }
}