import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { map, catchError } from 'rxjs/operators';
import { of } from 'rxjs';
import { Question, CreateQuestionRequest, QuestionOption } from '../models/question.model';

@Injectable({
  providedIn: 'root'
})
export class QuestionService {
  private apiUrl = 'http://localhost:3000/api';
  private questionsSubject = new BehaviorSubject<Question[]>([]);
  public questions$ = this.questionsSubject.asObservable();

  constructor(private http: HttpClient) {}

  createQuestion(surveyId: string, questionData: CreateQuestionRequest): Observable<Question> {
    const payload = {
      surveyId,
      ...questionData
    };

    return this.http.post<any>(`${this.apiUrl}/questions`, payload).pipe(
      map(response => {
        if (response.success && response.question) {
          const question: Question = {
            id: response.question.id,
            surveyId: response.question.surveyId,
            type: response.question.type,
            title: response.question.title,
            description: response.question.description,
            required: response.question.required,
            order: response.question.order,
            options: response.question.options,
            validation: response.question.validation
          };

          // Update local state
          const currentQuestions = this.questionsSubject.value;
          this.questionsSubject.next([...currentQuestions, question]);
          
          return question;
        }
        throw new Error('فشل في إنشاء السؤال');
      }),
      catchError(error => {
        console.error('Create question error:', error);
        const errorMessage = error.error?.message || 'حدث خطأ أثناء إنشاء السؤال';
        throw new Error(errorMessage);
      })
    );
  }

  loadQuestionsBySurveyId(surveyId: string): Observable<Question[]> {
    return this.http.get<any>(`${this.apiUrl}/questions/survey/${surveyId}`).pipe(
      map(response => {
        if (response.success && response.questions) {
          const questions = response.questions.map((question: any) => ({
            id: question.id,
            surveyId: question.surveyId,
            type: question.type,
            title: question.title,
            description: question.description,
            required: question.required,
            order: question.order,
            options: question.options,
            validation: question.validation
          }));
          
          // Update local state for this survey
          const currentQuestions = this.questionsSubject.value;
          const otherQuestions = currentQuestions.filter(q => q.surveyId !== surveyId);
          this.questionsSubject.next([...otherQuestions, ...questions]);
          
          return questions;
        }
        return [];
      }),
      catchError(error => {
        console.error('Load questions error:', error);
        return of([]);
      })
    );
  }

  getQuestionsBySurveyId(surveyId: string): Question[] {
    return this.questionsSubject.value
      .filter(q => q.surveyId === surveyId)
      .sort((a, b) => a.order - b.order);
  }

  updateQuestionOrder(surveyId: string, questionId: string, newOrder: number): Observable<boolean> {
    return this.http.patch<any>(`${this.apiUrl}/questions/${questionId}/order`, { newOrder }).pipe(
      map(response => {
        if (response.success) {
          // Reload questions to get updated order
          this.loadQuestionsBySurveyId(surveyId).subscribe();
          return true;
        }
        return false;
      }),
      catchError(error => {
        console.error('Update question order error:', error);
        return of(false);
      })
    );
  }

  deleteQuestion(questionId: string): Observable<boolean> {
    return this.http.delete<any>(`${this.apiUrl}/questions/${questionId}`).pipe(
      map(response => {
        if (response.success) {
          // Update local state
          const currentQuestions = this.questionsSubject.value;
          const updatedQuestions = currentQuestions.filter(q => q.id !== questionId);
          this.questionsSubject.next(updatedQuestions);
          return true;
        }
        return false;
      }),
      catchError(error => {
        console.error('Delete question error:', error);
        return of(false);
      })
    );
  }

  updateQuestion(questionId: string, questionData: Partial<CreateQuestionRequest>): Observable<Question> {
    return new Observable(observer => {
      const currentQuestions = this.questionsSubject.value;
      const questionIndex = currentQuestions.findIndex(q => q.id === questionId);
      
      if (questionIndex === -1) {
        observer.error(new Error('السؤال غير موجود'));
        return;
      }

      const options: QuestionOption[] | undefined = questionData.options?.map((opt, index) => ({
        id: `opt_${Date.now()}_${index}`,
        text: opt.text,
        value: opt.value
      }));

      const updatedQuestion: Question = {
        ...currentQuestions[questionIndex],
        ...questionData,
        options: options || currentQuestions[questionIndex].options
      };

      const updatedQuestions = [...currentQuestions];
      updatedQuestions[questionIndex] = updatedQuestion;
      
      this.questionsSubject.next(updatedQuestions);
      this.saveQuestions();
      
      observer.next(updatedQuestion);
      observer.complete();
    });
  }

  getQuestionsCount(surveyId: string): Observable<number> {
    return this.http.get<any>(`${this.apiUrl}/questions/survey/${surveyId}/count`).pipe(
      map(response => {
        if (response.success) {
          return response.count;
        }
        return 0;
      }),
      catchError(() => of(0))
    );
  }

  getQuestionsCountSync(surveyId: string): number {
    return this.questionsSubject.value.filter(q => q.surveyId === surveyId).length;
  }
}