import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CreateQuestionRequest, QuestionType, QUESTION_TYPES } from '../../models/question.model';

@Component({
  selector: 'app-question-form',
  templateUrl: './question-form.component.html',
  styleUrls: ['./question-form.component.scss']
})
export class QuestionFormComponent implements OnInit {
  @Input() surveyId: string = '';
  @Output() questionCreated = new EventEmitter<CreateQuestionRequest>();
  @Output() cancelled = new EventEmitter<void>();

  questionForm: FormGroup;
  questionTypes = QUESTION_TYPES;
  availableTypes: QuestionType[] = Object.keys(QUESTION_TYPES) as QuestionType[];
  loading = false;
  showForm = false;

  constructor(private formBuilder: FormBuilder) {
    this.questionForm = this.formBuilder.group({
      type: ['', Validators.required],
      title: ['', [Validators.required, Validators.minLength(3)]],
      description: [''],
      required: [false],
      options: this.formBuilder.array([]),
      validation: this.formBuilder.group({
        min: [''],
        max: [''],
        minLength: [''],
        maxLength: [''],
        pattern: ['']
      })
    });
  }

  ngOnInit(): void {
    // Watch for type changes to show/hide relevant fields
    this.questionForm.get('type')?.valueChanges.subscribe(type => {
      this.onTypeChange(type);
    });
  }

  get optionsArray(): FormArray {
    return this.questionForm.get('options') as FormArray;
  }

  toggleForm(): void {
    this.showForm = !this.showForm;
    if (!this.showForm) {
      this.resetForm();
    }
  }

  onTypeChange(type: QuestionType): void {
    // Clear existing options
    while (this.optionsArray.length !== 0) {
      this.optionsArray.removeAt(0);
    }

    // Add default options for choice questions
    if (type === 'single_choice' || type === 'multiple_choice') {
      this.addOption();
      this.addOption();
    }
  }

  addOption(): void {
    const optionGroup = this.formBuilder.group({
      text: ['', Validators.required],
      value: ['', Validators.required]
    });
    this.optionsArray.push(optionGroup);
  }

  removeOption(index: number): void {
    if (this.optionsArray.length > 1) {
      this.optionsArray.removeAt(index);
    }
  }

  needsOptions(): boolean {
    const type = this.questionForm.get('type')?.value;
    return type === 'single_choice' || type === 'multiple_choice';
  }

  needsValidation(): boolean {
    const type = this.questionForm.get('type')?.value;
    return type === 'numeric' || type === 'text' || type === 'phone';
  }

  onSubmit(): void {
    if (this.questionForm.valid) {
      this.loading = true;
      
      const formValue = this.questionForm.value;
      const questionData: CreateQuestionRequest = {
        type: formValue.type,
        title: formValue.title,
        description: formValue.description || undefined,
        required: formValue.required,
        options: this.needsOptions() ? formValue.options : undefined,
        validation: this.needsValidation() ? this.buildValidation(formValue) : undefined
      };

      // Emit the question data
      this.questionCreated.emit(questionData);
      
      // Reset form after successful creation
      setTimeout(() => {
        this.loading = false;
        this.resetForm();
        this.showForm = false;
      }, 500);
    } else {
      this.markFormGroupTouched();
    }
  }

  private buildValidation(formValue: any): CreateQuestionRequest['validation'] {
    const validation: any = {};
    const validationForm = formValue.validation;

    if (validationForm.min !== '') validation.min = Number(validationForm.min);
    if (validationForm.max !== '') validation.max = Number(validationForm.max);
    if (validationForm.minLength !== '') validation.minLength = Number(validationForm.minLength);
    if (validationForm.maxLength !== '') validation.maxLength = Number(validationForm.maxLength);
    if (validationForm.pattern !== '') validation.pattern = validationForm.pattern;

    return Object.keys(validation).length > 0 ? validation : undefined;
  }

  private resetForm(): void {
    this.questionForm.reset();
    while (this.optionsArray.length !== 0) {
      this.optionsArray.removeAt(0);
    }
    this.questionForm.patchValue({
      required: false,
      type: '',
      title: '',
      description: ''
    });
  }

  private markFormGroupTouched(): void {
    Object.keys(this.questionForm.controls).forEach(key => {
      const control = this.questionForm.get(key);
      control?.markAsTouched();
    });

    // Mark options as touched
    this.optionsArray.controls.forEach(optionControl => {
      Object.keys(optionControl.value).forEach(optionKey => {
        optionControl.get(optionKey)?.markAsTouched();
      });
    });
  }

  cancel(): void {
    this.showForm = false;
    this.resetForm();
    this.cancelled.emit();
  }

  isFieldInvalid(fieldName: string): boolean {
    const field = this.questionForm.get(fieldName);
    return !!(field && field.invalid && field.touched);
  }

  isOptionFieldInvalid(index: number, fieldName: string): boolean {
    const option = this.optionsArray.at(index);
    const field = option?.get(fieldName);
    return !!(field && field.invalid && field.touched);
  }

  getFieldError(fieldName: string): string {
    const field = this.questionForm.get(fieldName);
    if (field?.errors) {
      if (field.errors['required']) return 'هذا الحقل مطلوب';
      if (field.errors['minlength']) return `الحد الأدنى ${field.errors['minlength'].requiredLength} أحرف`;
    }
    return '';
  }
}