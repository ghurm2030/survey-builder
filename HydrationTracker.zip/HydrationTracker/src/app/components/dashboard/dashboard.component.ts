import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService, User } from '../../services/auth.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  currentUser: User | null = null;

  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.currentUser = this.authService.getCurrentUser();
    
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
      if (!user) {
        this.router.navigate(['/login']);
      }
    });
  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  getWelcomeMessage(): string {
    if (!this.currentUser) return 'مرحباً';
    
    const { identifier, type } = this.currentUser;
    
    switch (type) {
      case 'name':
        return `مرحباً ${identifier}`;
      case 'email':
        return `مرحباً بك`;
      case 'phone':
        return `مرحباً بك`;
      default:
        return 'مرحباً بك';
    }
  }

  getUserTypeLabel(): string {
    if (!this.currentUser) return '';
    
    switch (this.currentUser.type) {
      case 'name':
        return 'الاسم';
      case 'email':
        return 'البريد الإلكتروني';
      case 'phone':
        return 'رقم الجوال';
      default:
        return '';
    }
  }

  createSurvey(): void {
    this.router.navigate(['/create-survey']);
  }

  uploadFromFile(): void {
    this.router.navigate(['/excel-upload']);
  }

  generateTemplate(): void {
    this.router.navigate(['/template-generator']);
  }

  viewSurveys(): void {
    this.router.navigate(['/surveys']);
  }

  manageUsers(): void {
    this.router.navigate(['/users']);
  }

  isAdmin(): boolean {
    return this.currentUser?.role === 'admin';
  }
}