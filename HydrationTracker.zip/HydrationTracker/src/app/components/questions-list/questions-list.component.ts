import { Component, Input, OnInit } from '@angular/core';
import { QuestionService } from '../../services/question.service';
import { Question, QUESTION_TYPES } from '../../models/question.model';

@Component({
  selector: 'app-questions-list',
  templateUrl: './questions-list.component.html',
  styleUrls: ['./questions-list.component.scss']
})
export class QuestionsListComponent implements OnInit {
  @Input() surveyId: string = '';
  
  questions: Question[] = [];
  questionTypes = QUESTION_TYPES;
  loading = true;

  constructor(private questionService: QuestionService) {}

  ngOnInit(): void {
    this.loadQuestions();
    
    // Subscribe to questions changes
    this.questionService.questions$.subscribe(() => {
      this.questions = this.questionService.getQuestionsBySurveyId(this.surveyId);
    });
  }

  loadQuestions(): void {
    if (this.surveyId) {
      this.questionService.loadQuestionsBySurveyId(this.surveyId).subscribe({
        next: (questions) => {
          this.questions = questions;
          this.loading = false;
        },
        error: (error) => {
          console.error('Error loading questions:', error);
          this.loading = false;
        }
      });
    }
  }

  deleteQuestion(questionId: string): void {
    if (confirm('هل أنت متأكد من حذف هذا السؤال؟')) {
      this.questionService.deleteQuestion(questionId).subscribe({
        next: () => {
          this.loadQuestions();
        },
        error: (error) => {
          console.error('Error deleting question:', error);
          alert('حدث خطأ أثناء حذف السؤال');
        }
      });
    }
  }

  moveQuestionUp(question: Question): void {
    if (question.order > 1) {
      this.questionService.updateQuestionOrder(this.surveyId, question.id, question.order - 1).subscribe({
        next: (success) => {
          if (!success) {
            alert('حدث خطأ أثناء تحديث ترتيب السؤال');
          }
        }
      });
    }
  }

  moveQuestionDown(question: Question): void {
    const maxOrder = Math.max(...this.questions.map(q => q.order));
    if (question.order < maxOrder) {
      this.questionService.updateQuestionOrder(this.surveyId, question.id, question.order + 1).subscribe({
        next: (success) => {
          if (!success) {
            alert('حدث خطأ أثناء تحديث ترتيب السؤال');
          }
        }
      });
    }
  }

  getQuestionTypeIcon(type: string): string {
    const icons: { [key: string]: string } = {
      'numeric': '🔢',
      'text': '📝',
      'single_choice': '⚪',
      'multiple_choice': '☑️',
      'date': '📅',
      'time': '⏰',
      'phone': '📱'
    };
    return icons[type] || '❓';
  }

  hasOptions(question: Question): boolean {
    return question.type === 'single_choice' || question.type === 'multiple_choice';
  }

  hasValidation(question: Question): boolean {
    return !!question.validation && Object.keys(question.validation).length > 0;
  }

  getValidationText(question: Question): string {
    if (!question.validation) return '';
    
    const validation = question.validation;
    const rules: string[] = [];

    if (validation.min !== undefined) rules.push(`أقل قيمة: ${validation.min}`);
    if (validation.max !== undefined) rules.push(`أعلى قيمة: ${validation.max}`);
    if (validation.minLength !== undefined) rules.push(`أقل عدد أحرف: ${validation.minLength}`);
    if (validation.maxLength !== undefined) rules.push(`أعلى عدد أحرف: ${validation.maxLength}`);
    if (validation.pattern) rules.push(`نمط: ${validation.pattern}`);

    return rules.join(' | ');
  }

  trackByQuestionId(index: number, question: Question): string {
    return question.id;
  }
}