import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService, CreateUserRequest, UserDetails } from '../../services/user.service';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-users-management',
  templateUrl: './users-management.component.html',
  styleUrls: ['./users-management.component.scss']
})
export class UsersManagementComponent implements OnInit {
  users: UserDetails[] = [];
  filteredUsers: UserDetails[] = [];
  userForm: FormGroup;
  loading = false;
  creating = false;
  showCreateForm = false;
  errorMessage = '';
  successMessage = '';
  filterRole: 'all' | 'admin' | 'user' = 'all';
  filterStatus: 'all' | 'active' | 'inactive' = 'all';

  constructor(
    private formBuilder: FormBuilder,
    private userService: UserService,
    private authService: AuthService,
    private router: Router
  ) {
    this.userForm = this.formBuilder.group({
      identifier: ['', [Validators.required, Validators.minLength(3)]],
      role: ['user', Validators.required],
      name: [''],
      email: ['', [Validators.email]],
      phone: ['']
    });
  }

  ngOnInit(): void {
    // Check if current user is admin
    const currentUser = this.authService.getCurrentUser();
    if (!currentUser || currentUser.role !== 'admin') {
      this.router.navigate(['/dashboard']);
      return;
    }

    this.loadUsers();
  }

  loadUsers(): void {
    this.loading = true;
    this.userService.getUsers().subscribe({
      next: (users) => {
        this.users = users;
        this.applyFilters();
        this.loading = false;
      },
      error: (error) => {
        console.error('Error loading users:', error);
        this.errorMessage = 'حدث خطأ أثناء تحميل المستخدمين';
        this.loading = false;
      }
    });
  }

  onCreateUser(): void {
    if (this.userForm.valid) {
      this.creating = true;
      this.errorMessage = '';
      this.successMessage = '';

      const currentUser = this.authService.getCurrentUser();
      if (!currentUser) {
        this.errorMessage = 'يجب تسجيل الدخول';
        this.creating = false;
        return;
      }

      const userData: CreateUserRequest = {
        identifier: this.userForm.get('identifier')?.value,
        role: this.userForm.get('role')?.value,
        name: this.userForm.get('name')?.value || undefined,
        email: this.userForm.get('email')?.value || undefined,
        phone: this.userForm.get('phone')?.value || undefined
      };

      this.userService.createUser(userData, currentUser.identifier).subscribe({
        next: (user) => {
          this.creating = false;
          this.successMessage = 'تم إنشاء المستخدم بنجاح';
          this.userForm.reset();
          this.userForm.patchValue({ role: 'user' });
          this.showCreateForm = false;
          this.loadUsers();
        },
        error: (error) => {
          this.creating = false;
          this.errorMessage = error.message || 'حدث خطأ أثناء إنشاء المستخدم';
        }
      });
    } else {
      this.markFormGroupTouched();
      this.errorMessage = 'يرجى ملء الحقول المطلوبة بشكل صحيح';
    }
  }

  toggleUserStatus(user: UserDetails): void {
    const newStatus = !user.isActive;
    this.userService.updateUser(user.id, { isActive: newStatus }).subscribe({
      next: (updatedUser) => {
        const index = this.users.findIndex(u => u.id === user.id);
        if (index !== -1) {
          this.users[index] = updatedUser;
          this.applyFilters();
        }
        this.successMessage = newStatus ? 'تم تفعيل المستخدم' : 'تم إلغاء تفعيل المستخدم';
      },
      error: (error) => {
        this.errorMessage = error.message || 'حدث خطأ أثناء تحديث المستخدم';
      }
    });
  }

  deleteUser(user: UserDetails): void {
    if (confirm(`هل أنت متأكد من حذف المستخدم "${user.identifier}"؟`)) {
      this.userService.deleteUser(user.id).subscribe({
        next: (success) => {
          if (success) {
            this.users = this.users.filter(u => u.id !== user.id);
            this.applyFilters();
            this.successMessage = 'تم حذف المستخدم بنجاح';
          } else {
            this.errorMessage = 'فشل في حذف المستخدم';
          }
        },
        error: (error) => {
          this.errorMessage = 'حدث خطأ أثناء حذف المستخدم';
        }
      });
    }
  }

  onFilterChange(): void {
    this.applyFilters();
  }

  applyFilters(): void {
    this.filteredUsers = this.users.filter(user => {
      const roleMatch = this.filterRole === 'all' || user.role === this.filterRole;
      const statusMatch = this.filterStatus === 'all' || 
                         (this.filterStatus === 'active' && user.isActive) ||
                         (this.filterStatus === 'inactive' && !user.isActive);
      
      return roleMatch && statusMatch;
    });
  }

  toggleCreateForm(): void {
    this.showCreateForm = !this.showCreateForm;
    if (!this.showCreateForm) {
      this.userForm.reset();
      this.userForm.patchValue({ role: 'user' });
      this.errorMessage = '';
      this.successMessage = '';
    }
  }

  goBack(): void {
    this.router.navigate(['/dashboard']);
  }

  private markFormGroupTouched(): void {
    Object.keys(this.userForm.controls).forEach(key => {
      const control = this.userForm.get(key);
      control?.markAsTouched();
    });
  }

  isFieldInvalid(fieldName: string): boolean {
    const field = this.userForm.get(fieldName);
    return !!(field && field.invalid && field.touched);
  }

  getFieldError(fieldName: string): string {
    const field = this.userForm.get(fieldName);
    if (field?.errors) {
      if (field.errors['required']) return 'هذا الحقل مطلوب';
      if (field.errors['minlength']) return `الحد الأدنى ${field.errors['minlength'].requiredLength} أحرف`;
      if (field.errors['email']) return 'تنسيق البريد الإلكتروني غير صحيح';
    }
    return '';
  }

  getRoleLabel(role: string): string {
    return role === 'admin' ? 'مدير' : 'مستخدم عادي';
  }

  getStatusLabel(isActive: boolean): string {
    return isActive ? 'نشط' : 'غير نشط';
  }

  formatDate(date: Date): string {
    return new Intl.DateTimeFormat('ar-SA', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  }
}