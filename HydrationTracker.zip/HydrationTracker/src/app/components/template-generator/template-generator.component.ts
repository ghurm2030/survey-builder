import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SurveyService } from '../../services/survey.service';
import { AuthService } from '../../services/auth.service';
import { HttpClient } from '@angular/common/http';

interface Category {
  id: string;
  name: string;
  nameEn: string;
}

@Component({
  selector: 'app-template-generator',
  templateUrl: './template-generator.component.html',
  styleUrls: ['./template-generator.component.scss']
})
export class TemplateGeneratorComponent implements OnInit {
  generatorForm: FormGroup;
  categories: Category[] = [];
  loading = false;
  errorMessage = '';
  successMessage = '';
  generatedSurvey: any = null;
  
  private apiUrl = 'http://localhost:3000/api';

  constructor(
    private formBuilder: FormBuilder,
    private surveyService: SurveyService,
    private authService: AuthService,
    private router: Router,
    private http: HttpClient
  ) {
    this.generatorForm = this.formBuilder.group({
      description: ['', [Validators.required, Validators.minLength(10)]],
      category: ['general', Validators.required],
      targetAudience: [''],
      questionCount: [5, [Validators.required, Validators.min(3), Validators.max(20)]]
    });
  }

  ngOnInit(): void {
    const currentUser = this.authService.getCurrentUser();
    if (!currentUser) {
      this.router.navigate(['/login']);
      return;
    }

    this.loadCategories();
  }

  loadCategories(): void {
    this.http.get<{success: boolean, categories: Category[]}>(`${this.apiUrl}/surveys/categories`)
      .subscribe({
        next: (response) => {
          if (response.success) {
            this.categories = response.categories;
          }
        },
        error: (error) => {
          console.error('Error loading categories:', error);
          this.errorMessage = 'خطأ في تحميل الفئات';
        }
      });
  }

  generateTemplate(): void {
    if (this.generatorForm.invalid) {
      this.markFormGroupTouched();
      return;
    }

    const currentUser = this.authService.getCurrentUser();
    if (!currentUser) {
      this.errorMessage = 'يجب تسجيل الدخول أولاً';
      return;
    }

    this.loading = true;
    this.clearMessages();

    const formValue = this.generatorForm.value;
    const requestData = {
      ...formValue,
      createdBy: currentUser.identifier
    };

    this.http.post<any>(`${this.apiUrl}/surveys/generate-template`, requestData)
      .subscribe({
        next: (response) => {
          this.loading = false;
          if (response.success) {
            this.successMessage = response.message;
            this.generatedSurvey = response;
            
            // Refresh surveys list
            this.surveyService.loadSurveysByUser(currentUser.identifier).subscribe();
            
            // Auto-redirect after success
            setTimeout(() => {
              this.router.navigate(['/surveys']);
            }, 3000);
          } else {
            this.errorMessage = response.message || 'حدث خطأ أثناء إنشاء القالب';
          }
        },
        error: (error) => {
          this.loading = false;
          console.error('Template generation error:', error);
          this.errorMessage = error.error?.message || 'حدث خطأ أثناء إنشاء القالب';
        }
      });
  }

  clearMessages(): void {
    this.errorMessage = '';
    this.successMessage = '';
  }

  private markFormGroupTouched(): void {
    Object.keys(this.generatorForm.controls).forEach(key => {
      const control = this.generatorForm.get(key);
      if (control) {
        control.markAsTouched();
      }
    });
  }

  isFieldInvalid(fieldName: string): boolean {
    const field = this.generatorForm.get(fieldName);
    return !!(field && field.invalid && field.touched);
  }

  getFieldError(fieldName: string): string {
    const field = this.generatorForm.get(fieldName);
    
    if (field && field.errors && field.touched) {
      if (field.errors['required']) {
        return 'هذا الحقل مطلوب';
      }
      if (field.errors['minlength']) {
        return `يجب أن يكون الحد الأدنى ${field.errors['minlength'].requiredLength} أحرف`;
      }
      if (field.errors['min']) {
        return `يجب أن يكون أكبر من ${field.errors['min'].min}`;
      }
      if (field.errors['max']) {
        return `يجب أن يكون أصغر من ${field.errors['max'].max}`;
      }
    }
    
    return '';
  }

  getCategoryName(categoryId: string): string {
    const category = this.categories.find(c => c.id === categoryId);
    return category ? category.name : categoryId;
  }

  goBack(): void {
    this.router.navigate(['/dashboard']);
  }

  viewGeneratedQuestions(): void {
    if (this.generatedSurvey && this.generatedSurvey.survey) {
      this.router.navigate(['/surveys']);
    }
  }

  getQuestionTypeLabel(type: string): string {
    const typeLabels: { [key: string]: string } = {
      'text': 'نصي',
      'numeric': 'رقمي',
      'single_choice': 'اختيار واحد',
      'multiple_choice': 'اختيار متعدد',
      'date': 'تاريخ',
      'time': 'وقت',
      'phone': 'رقم الجوال'
    };
    return typeLabels[type] || type;
  }
}