import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SurveyService } from '../../services/survey.service';
import { QuestionService } from '../../services/question.service';
import { AuthService } from '../../services/auth.service';
import { Survey } from '../../models/survey.model';

@Component({
  selector: 'app-surveys-list',
  templateUrl: './surveys-list.component.html',
  styleUrls: ['./surveys-list.component.scss']
})
export class SurveysListComponent implements OnInit {
  surveys: Survey[] = [];
  loading = true;

  constructor(
    private surveyService: SurveyService,
    private questionService: QuestionService,
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loadSurveys();
    
    // Subscribe to survey changes
    this.surveyService.surveys$.subscribe(surveys => {
      this.surveys = surveys;
      this.loading = false;
    });
  }

  loadSurveys(): void {
    const currentUser = this.authService.getCurrentUser();
    if (currentUser) {
      this.surveyService.loadSurveysByUser(currentUser.identifier).subscribe({
        next: (surveys) => {
          this.surveys = surveys;
          this.loading = false;
        },
        error: (error) => {
          console.error('Error loading surveys:', error);
          this.loading = false;
        }
      });
    } else {
      this.loading = false;
    }
  }

  createNewSurvey(): void {
    this.router.navigate(['/create-survey']);
  }

  goBack(): void {
    this.router.navigate(['/dashboard']);
  }

  formatDate(date: Date): string {
    return new Intl.DateTimeFormat('ar-SA', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  }

  getSurveyStatus(survey: Survey): { text: string; class: string } {
    const now = new Date();
    
    if (now < survey.startDateTime) {
      return { text: 'لم يبدأ بعد', class: 'pending' };
    } else if (now >= survey.startDateTime && now <= survey.endDateTime) {
      return { text: 'نشط', class: 'active' };
    } else {
      return { text: 'منتهي', class: 'expired' };
    }
  }

  getUserSurveys(): Survey[] {
    const currentUser = this.authService.getCurrentUser();
    if (!currentUser) return [];
    
    return this.surveys.filter(survey => survey.createdBy === currentUser.identifier);
  }
}