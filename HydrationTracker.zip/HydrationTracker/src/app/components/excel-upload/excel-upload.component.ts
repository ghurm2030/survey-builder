import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SurveyService } from '../../services/survey.service';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-excel-upload',
  templateUrl: './excel-upload.component.html',
  styleUrls: ['./excel-upload.component.scss']
})
export class ExcelUploadComponent implements OnInit {
  uploadForm: FormGroup;
  selectedFile: File | null = null;
  fileType: 'excel' | 'word' = 'excel';
  loading = false;
  errorMessage = '';
  successMessage = '';
  uploadResult: any = null;

  constructor(
    private formBuilder: FormBuilder,
    private surveyService: SurveyService,
    private authService: AuthService,
    private router: Router
  ) {
    this.uploadForm = this.formBuilder.group({
      fileType: ['excel', Validators.required]
    });
  }

  ngOnInit(): void {
    // Check if user is logged in
    const currentUser = this.authService.getCurrentUser();
    if (!currentUser) {
      this.router.navigate(['/login']);
    }
  }

  onFileTypeChange(): void {
    this.fileType = this.uploadForm.get('fileType')?.value;
    this.selectedFile = null;
    this.clearMessages();
  }

  onFileSelected(event: any): void {
    const file = event.target.files[0];
    if (file) {
      const isValidFile = this.validateFile(file);
      if (isValidFile) {
        this.selectedFile = file;
        this.clearMessages();
      } else {
        this.selectedFile = null;
        event.target.value = '';
      }
    }
  }

  validateFile(file: File): boolean {
    const maxSize = 10 * 1024 * 1024; // 10MB
    
    if (file.size > maxSize) {
      this.errorMessage = 'حجم الملف كبير جداً. الحد الأقصى 10 ميجابايت';
      return false;
    }

    if (this.fileType === 'excel') {
      const validExcelTypes = [
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/vnd.ms-excel'
      ];
      if (!validExcelTypes.includes(file.type)) {
        this.errorMessage = 'يجب أن يكون الملف من نوع Excel (.xlsx أو .xls)';
        return false;
      }
    } else if (this.fileType === 'word') {
      const validWordTypes = [
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/msword'
      ];
      if (!validWordTypes.includes(file.type)) {
        this.errorMessage = 'يجب أن يكون الملف من نوع Word (.docx أو .doc)';
        return false;
      }
    }

    return true;
  }

  downloadTemplate(): void {
    this.loading = true;
    const currentUser = this.authService.getCurrentUser();
    
    if (!currentUser) {
      this.errorMessage = 'يجب تسجيل الدخول أولاً';
      this.loading = false;
      return;
    }

    const templateUrl = this.fileType === 'excel' 
      ? '/api/surveys/download-template' 
      : '/api/surveys/download-word-template';

    // Create a temporary link to download the file
    const link = document.createElement('a');
    link.href = `http://localhost:3000${templateUrl}`;
    link.download = this.fileType === 'excel' ? 'survey-template.xlsx' : 'survey-template.txt';
    
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    this.loading = false;
    this.successMessage = 'تم تحميل القالب بنجاح';
    setTimeout(() => this.clearMessages(), 3000);
  }

  uploadFile(): void {
    if (!this.selectedFile) {
      this.errorMessage = 'يجب اختيار ملف أولاً';
      return;
    }

    const currentUser = this.authService.getCurrentUser();
    if (!currentUser) {
      this.errorMessage = 'يجب تسجيل الدخول أولاً';
      return;
    }

    this.loading = true;
    this.clearMessages();

    const formData = new FormData();
    formData.append(this.fileType === 'excel' ? 'excelFile' : 'wordFile', this.selectedFile);
    formData.append('createdBy', currentUser.identifier);

    const uploadUrl = this.fileType === 'excel' 
      ? 'http://localhost:3000/api/surveys/upload-excel'
      : 'http://localhost:3000/api/surveys/upload-word';

    fetch(uploadUrl, {
      method: 'POST',
      body: formData
    })
    .then(response => response.json())
    .then(data => {
      this.loading = false;
      
      if (data.success) {
        this.successMessage = data.message;
        this.uploadResult = data;
        
        // Clear the file input
        this.selectedFile = null;
        const fileInput = document.getElementById('fileInput') as HTMLInputElement;
        if (fileInput) fileInput.value = '';
        
        // Refresh surveys list in the service
        this.surveyService.loadSurveysByUser(currentUser.identifier).subscribe();
        
        setTimeout(() => {
          this.router.navigate(['/surveys']);
        }, 2000);
      } else {
        this.errorMessage = data.message || 'حدث خطأ أثناء رفع الملف';
      }
    })
    .catch(error => {
      this.loading = false;
      console.error('Upload error:', error);
      this.errorMessage = 'حدث خطأ أثناء رفع الملف';
    });
  }

  clearMessages(): void {
    this.errorMessage = '';
    this.successMessage = '';
    this.uploadResult = null;
  }

  goBack(): void {
    this.router.navigate(['/dashboard']);
  }

  getFileTypeLabel(): string {
    return this.fileType === 'excel' ? 'Excel' : 'Word';
  }

  getAcceptedTypes(): string {
    return this.fileType === 'excel' 
      ? '.xlsx,.xls' 
      : '.docx,.doc';
  }
}