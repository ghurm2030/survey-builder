import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  loading = false;
  errorMessage = '';
  successMessage = '';

  constructor(
    private formBuilder: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {
    this.loginForm = this.formBuilder.group({
      identifier: ['', [Validators.required, Validators.minLength(3)]]
    });
  }

  ngOnInit(): void {
    if (this.authService.isLoggedIn()) {
      this.router.navigate(['/dashboard']);
    }
  }

  onSubmit(): void {
    if (this.loginForm.valid) {
      this.loading = true;
      this.errorMessage = '';
      this.successMessage = '';

      const identifier = this.loginForm.get('identifier')?.value;

      this.authService.login(identifier).subscribe({
        next: (success) => {
          this.loading = false;
          if (success) {
            this.successMessage = 'تم تسجيل الدخول بنجاح!';
            setTimeout(() => {
              this.router.navigate(['/dashboard']);
            }, 1000);
          } else {
            this.errorMessage = 'خطأ في تسجيل الدخول. يرجى المحاولة مرة أخرى.';
          }
        },
        error: () => {
          this.loading = false;
          this.errorMessage = 'حدث خطأ غير متوقع. يرجى المحاولة مرة أخرى.';
        }
      });
    } else {
      this.errorMessage = 'يرجى إدخال اسم صالح أو رقم جوال أو بريد إلكتروني';
    }
  }

  getPlaceholderText(): string {
    return 'الاسم أو رقم الجوال أو البريد الإلكتروني';
  }
}