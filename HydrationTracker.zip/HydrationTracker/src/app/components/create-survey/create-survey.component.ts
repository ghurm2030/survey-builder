import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SurveyService } from '../../services/survey.service';
import { QuestionService } from '../../services/question.service';
import { AuthService } from '../../services/auth.service';
import { CreateQuestionRequest } from '../../models/question.model';

@Component({
  selector: 'app-create-survey',
  templateUrl: './create-survey.component.html',
  styleUrls: ['./create-survey.component.scss']
})
export class CreateSurveyComponent implements OnInit {
  surveyForm: FormGroup;
  loading = false;
  errorMessage = '';
  successMessage = '';
  createdSurveyId: string = '';

  constructor(
    private formBuilder: FormBuilder,
    private surveyService: SurveyService,
    private questionService: QuestionService,
    private authService: AuthService,
    private router: Router
  ) {
    this.surveyForm = this.formBuilder.group({
      uniqueNumber: ['', [Validators.required, Validators.pattern(/^[A-Za-z0-9]+$/)]],
      descriptionArabic: ['', [Validators.required, Validators.minLength(10)]],
      descriptionEnglish: ['', [Validators.required, Validators.minLength(10)]],
      startDateTime: ['', Validators.required],
      endDateTime: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    // Generate a unique number by default
    this.generateUniqueNumber();
  }

  generateUniqueNumber(): void {
    this.surveyService.generateUniqueNumber().subscribe({
      next: (uniqueNumber) => {
        this.surveyForm.patchValue({ uniqueNumber });
      },
      error: (error) => {
        console.error('Error generating unique number:', error);
        // Fallback to local generation
        const timestamp = Date.now().toString().slice(-6);
        const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
        const fallbackNumber = `SV${timestamp}${random}`;
        this.surveyForm.patchValue({ uniqueNumber: fallbackNumber });
      }
    });
  }

  onSubmit(): void {
    if (this.surveyForm.valid) {
      this.loading = true;
      this.errorMessage = '';
      this.successMessage = '';

      const formValue = this.surveyForm.value;
      const currentUser = this.authService.getCurrentUser();

      if (!currentUser) {
        this.errorMessage = 'يجب تسجيل الدخول أولاً';
        this.loading = false;
        return;
      }

      const surveyData = {
        uniqueNumber: formValue.uniqueNumber,
        descriptionArabic: formValue.descriptionArabic,
        descriptionEnglish: formValue.descriptionEnglish,
        startDateTime: new Date(formValue.startDateTime),
        endDateTime: new Date(formValue.endDateTime)
      };

      this.surveyService.createSurvey(surveyData, currentUser.identifier).subscribe({
        next: (survey) => {
          this.loading = false;
          this.successMessage = 'تم إنشاء الاستبيان بنجاح! يمكنك الآن إضافة الأسئلة';
          this.createdSurveyId = survey.id;
          // Disable the form after successful creation
          this.surveyForm.disable();
        },
        error: (error) => {
          this.loading = false;
          this.errorMessage = error.message || 'حدث خطأ أثناء إنشاء الاستبيان';
        }
      });
    } else {
      this.markFormGroupTouched();
      this.errorMessage = 'يرجى ملء جميع الحقول المطلوبة بشكل صحيح';
    }
  }

  private markFormGroupTouched(): void {
    Object.keys(this.surveyForm.controls).forEach(key => {
      const control = this.surveyForm.get(key);
      control?.markAsTouched();
    });
  }

  isFieldInvalid(fieldName: string): boolean {
    const field = this.surveyForm.get(fieldName);
    return !!(field && field.invalid && field.touched);
  }

  getFieldError(fieldName: string): string {
    const field = this.surveyForm.get(fieldName);
    if (field?.errors) {
      if (field.errors['required']) return 'هذا الحقل مطلوب';
      if (field.errors['minlength']) return `الحد الأدنى ${field.errors['minlength'].requiredLength} أحرف`;
      if (field.errors['pattern']) return 'يجب أن يحتوي على أحرف وأرقام فقط';
    }
    return '';
  }

  getCurrentDateTime(): string {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    
    return `${year}-${month}-${day}T${hours}:${minutes}`;
  }

  goBack(): void {
    this.router.navigate(['/dashboard']);
  }

  onQuestionCreated(questionData: CreateQuestionRequest): void {
    if (this.createdSurveyId) {
      this.questionService.createQuestion(this.createdSurveyId, questionData).subscribe({
        next: (question) => {
          // Question added successfully, the questions list will update automatically
        },
        error: (error) => {
          console.error('Error creating question:', error);
          alert('حدث خطأ أثناء إضافة السؤال');
        }
      });
    }
  }

  finishSurvey(): void {
    this.questionService.getQuestionsCount(this.createdSurveyId).subscribe({
      next: (questionsCount) => {
        if (questionsCount === 0) {
          if (!confirm('لم تقم بإضافة أي أسئلة للاستبيان. هل أنت متأكد من المتابعة؟')) {
            return;
          }
        }
        this.router.navigate(['/surveys']);
      },
      error: () => {
        // If there's an error getting count, just proceed
        this.router.navigate(['/surveys']);
      }
    });
  }
}